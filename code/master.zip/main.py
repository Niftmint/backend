import flask


def hello_name(request):
    """HTTP Cloud Function.
    Args:
        request (flask.Request): The request object.
        <http://flask.pocoo.org/docs/1.0/api/#flask.Request>
    Returns:
        The response text, or any set of values that can be turned into a
        Response object using `make_response`
        <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>.
    """
    request_args = request.args

    if request_args and "id" in request_args and "buyer" in request_args:
        id = request_args["id"]
        buyer = request_args["buyer"]
    else:
        id = "666"
        buyer = "Rui"
        
    return "buy NFT {} for {}".format(flask.escape(id), flask.escape(buyer))